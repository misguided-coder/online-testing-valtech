var numbers = [10,20,30,40,50,60,70,80];
console.log(numbers);
console.log("Length : " +numbers.length);

console.log(numbers[0]);

numbers.push(90);
numbers.push(100);
numbers.push(110);
numbers.push(120);

console.log(numbers);
console.log("Length : " +numbers.length);

numbers.pop();
numbers.pop();

console.log(numbers);
console.log("Length : " +numbers.length);

var names = ["Ram","Shyam","Jaggu","Chintu"];
console.log(names);
console.log("Length : " +names.length);


var array = numbers.concat(names);
console.log(array);
console.log("Length : " +array.length);




