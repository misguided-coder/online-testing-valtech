var age = 15;
var money = 25000;

if(age > 40 || money > 50000)  {
	console.log("You are old!!");
	console.log("You are very rich!!");
} else if(age > 20 && money > 15000) {
	console.log("You are little grown!!");
	console.log("You are rich!!");
} else {
	console.log("You are young!!");
	console.log("You are poor!!");
}




