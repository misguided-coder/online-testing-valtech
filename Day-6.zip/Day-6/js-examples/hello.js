//function declaration
function hello(name) {
	console.log("Hello Mr "+name)
	hi(name)
}

function hi(name) {
	console.log("Hi Mr "+name)
	bye(name);
}

function bye(name) {
	console.log("Bye Mr "+name)
}

//function invocation
hello("Rohan")