var count = 0;
	
while(count <= 10) {
	console.log("I am still not 10!!");
	count++;
}

console.log("Finish Line!!!!!");


count = 10;
	
do  {
	console.log("I am still not 10!!");
	count++;
} while(count <= 10);

console.log("Finish Line!!!!!");


for(var idx = 1;idx <= 5; idx++) {
	console.log("Hello, All is well!!");
}

console.log("Finish Line!!!!!");


var array = [34,54,2,33,4,3,5,44];

for(var idx = 0;idx < array.length; idx++) {
	console.log("Value is : "+array[idx]);
}

console.log("Finish Line!!!!!");

for(var value of array) {
	console.log("Value is : "+value);
}

console.log("Finish Line!!!!!");

var emp = {id:100,name:"Jaggu Singh",salary:12000.00,desig:"Lead",dept:"SW"};

for(var key in emp) {
	console.log("Key is : "+key);
	console.log("Value is : "+emp[key]);
}

console.log("Finish Line!!!!!");






