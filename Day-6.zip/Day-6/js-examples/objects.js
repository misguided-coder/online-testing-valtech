var date = new Date();
console.log(date);
console.log(typeof date);

console.log(date.getYear() + 1900);
console.log(date.getMonth() + 1);
console.log(date.getDate());


var string = new String("I am a just a JS string!!!");
console.log(string);
console.log(string.toUpperCase());
console.log(string.toLowerCase());
console.log(string.indexOf('j'));
console.log(string.charAt(5));
console.log(string.substring(5,10));


console.log(Math.random());
console.log(Math.min(34,23,12,34,67,7,8,9,12,4,3));
console.log(Math.max(34,23,12,34,67,7,8,9,12,4,3));
console.log(Math.floor(145.67));
console.log(Math.ceil(145.67));
console.log(Math.round(145.67));

//User defined object
//JSON
var emp = {id:100,name:"Jaggu Singh",salary:12000.00,desig:"Lead",dept:"SW"}; 
console.log(emp);
console.log(typeof emp);

console.log(emp.salary);
console.log(emp.name);


var person = {
		"uid":29382888888,
		"name":{
			"initials":"Mr",
			"firstName":"Jaggu",
			"lastName":"Singh"
		 },
		"phone":{"hand":"98818181811","office":"011928282828","whatsapp":"928272727272"},
		"languages":["English","German","Spanish","Hindi"]
	}; 

console.log(person);
console.log("===========================================");
console.log(person.uid);
console.log(person.name);
console.log(person.name.firstName);
console.log(person.phone);
console.log(person.phone.hand);
console.log(person.phone.whatsapp);
console.log(person.languages);
console.log(person.languages[2]);
console.log(person.languages[0]);















