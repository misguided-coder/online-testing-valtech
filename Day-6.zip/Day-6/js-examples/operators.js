var rs = 10 + 20;
console.log(rs);

rs = 90 - 20;
console.log(rs);

rs = 90 * 20;
console.log(rs);

rs = 90 / 20;
console.log(rs);

rs = 90 % 20;
console.log(rs);

var count = 100;
console.log(count);
console.log(count++); //post increment
console.log(++count); //pre increment

count = 100;
console.log(count);
console.log(count--); //post decrement
console.log(--count); //pre decrement

var salary = 12000.00;
salary = salary +  2000.00;
console.log(salary);
salary += 2000.00;
console.log(salary);



