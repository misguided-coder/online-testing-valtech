console.log("Welcone to JS!!!");
console.log("JS is functional!!!");
console.log("JS is simple to learn!!!");

var age = 10;
console.log(age);
console.log(typeof age);

//var name = "Sohan";
var name = 'Sohan';
console.log(name);
console.log(typeof name);

var status = true;
console.log(status);
console.log(typeof status);

var emp = null;
console.log(emp);
console.log(typeof emp);

var size;
console.log(size);
console.log(typeof size);
