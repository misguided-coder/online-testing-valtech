package com.example;

import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/cars")
public class AutomobileController {

	@Autowired
	CarService carService;

	// Add New Car
	@PostMapping(consumes = {MediaType.APPLICATION_JSON_VALUE}, produces = { MediaType.TEXT_PLAIN_VALUE})
	public  String addNewCar(@RequestBody Car car) {
		System.out.println("INFO =====> Inside AutomobileController.addNewCar()!!");
		return carService.addCar(car);
	}

	// Read All Cars
	@GetMapping(produces = { MediaType.APPLICATION_JSON_VALUE })
	public Collection<List<Car>> getAllCars() {
		System.out.println("INFO =====> Inside AutomobileController.getAllCars()!!");
		return carService.readAll();
	}

	// Read Cars By Type
	@GetMapping(path = "{carType}", produces = { MediaType.APPLICATION_JSON_VALUE })
	public Collection<Car> getAllCarsByType(@PathVariable("carType") String type) {
		System.out.println("INFO =====> Inside AutomobileController.getAllCarsByType()!!");
		return carService.readAllByType(type);
	}

}
