package com.example;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="car")
@XmlAccessorType(XmlAccessType.FIELD)
public class Car {

	@XmlElement(name="vin")
	int vin;
	
	@XmlElement(name="model")
	String model;
	
	@XmlElement(name="make")
	String make;
	
	@XmlElement(name="price")
	double price;
	
	@XmlElement(name="type")
	String type;

	public Car() {
	}
	
	public Car(String model, String make, double price, String type) {
		this.model = model;
		this.make = make;
		this.price = price;
		this.type = type;
	}

	public Car(int vin, String model, String make, double price, String type) {
		this.vin = vin;
		this.model = model;
		this.make = make;
		this.price = price;
		this.type = type;
	}

	public int getVin() {
		return vin;
	}

	public void setVin(int vin) {
		this.vin = vin;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getMake() {
		return make;
	}

	public void setMake(String make) {
		this.make = make;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

}
