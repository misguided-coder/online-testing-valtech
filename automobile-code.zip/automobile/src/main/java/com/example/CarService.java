package com.example;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

@Service
@Scope("singleton")
public class CarService {

	Map<String,List<Car>> inMemoryDB = new HashMap<>();
	
	@PostConstruct
	public void init() {

		List<Car> luxuryCars = new ArrayList<>();
		luxuryCars.add(new Car(101, "A2", "Audi", 12000.00, "luxury"));
		luxuryCars.add(new Car(102, "A5", "Audi", 16000.00, "luxury"));
		luxuryCars.add(new Car(103, "CLA", "Merc", 52000.00, "luxury"));
		luxuryCars.add(new Car(104, "CLQ", "Merc", 17000.00, "luxury"));

		List<Car> sportsCars = new ArrayList<>();
		sportsCars.add(new Car(105, "Q7", "Audi", 42000.00, "sports"));
		sportsCars.add(new Car(106, "Q5", "Audi", 26000.00, "sports"));
		sportsCars.add(new Car(107, "GLC", "Merc", 52000.00, "sports"));
		sportsCars.add(new Car(108, "X1", "BMW", 18000.00, "sports"));
		sportsCars.add(new Car(109, "X7", "BMW", 23000.00, "sports"));
		
		inMemoryDB.put("luxury", luxuryCars);
		inMemoryDB.put("sports", sportsCars);
		
	}

	public String addCar(Car car) {
		System.out.println("INFO =====> Inside CarService.addCar()!!");
		int vin = inMemoryDB.get("luxury").size() + inMemoryDB.get("sports").size() + 100 + 1;
		car.setVin(vin);
		System.out.println(car.getType());
		if(car.getType().equals("luxury")) {
			inMemoryDB.get("luxury").add(car);
		} else if(car.getType().equals("sports")) {
			inMemoryDB.get("sports").add(car);
		}
		return "New Car of type '"+car.getType()+"' added with "+vin;
	}

	public Collection<List<Car>> readAll() {
		System.out.println("INFO =====> Inside CarService.readAll()!!");
		return inMemoryDB.values();
	}
	
	//Read Cars By Type
	public Collection<Car> readAllByType(String type) {
		System.out.println("INFO =====> Inside CarService.readAllByType()!!");
		return inMemoryDB.get(type);
	}
	
}
