package com.example;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;

@WebService(name = "HRService",serviceName = "HRService",portName = "HRPort",targetNamespace = "http://example.hr.com")
public class HRService {

	@WebMethod(operationName = "hra")
	public double calculateHRA(@WebParam(name = "salary") double basicSalary) {
		System.out.println("Inside HRService.calculateHRA(" + basicSalary + ")!!!!");
		return basicSalary * 0.40;
	}

	@WebMethod(operationName = "da")
	public double calculateDA(@WebParam(name = "salary") double basicSalary) {
		System.out.println("Inside HRService.calculateDA(" + basicSalary + ")!!!!");
		return basicSalary * 0.08;
	}

	@WebMethod(operationName = "ta")
	public double calculateTA(@WebParam(name = "salary") double basicSalary) {
		System.out.println("Inside HRService.calculateTA(" + basicSalary + ")!!!!");
		return basicSalary * 0.05;
	}

	@WebMethod(operationName = "tds")
	public double calculateTDS(@WebParam(name = "salary") double basicSalary) {
		System.out.println("Inside HRService.calculateTDS(" + basicSalary + ")!!!!");
		return basicSalary * 0.30;
	}

}
