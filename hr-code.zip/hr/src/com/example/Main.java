package com.example;

import javax.xml.ws.Endpoint;

public class Main {

	public static void main(String[] args) {

		String host = "localhost";
		int port = 5000;

		if (args.length > 0 && args[0] != null && args[1] != null) {
			host = args[0];
			port = Integer.parseInt(args[1]);
		}

		HRService hrService = new HRService();
		String endpointURL = "http://" + host + ":" + port + "/services/HRService";
		Endpoint.publish(endpointURL, hrService);
		System.out.println("SOAP Endpoint is running on : " + endpointURL);
	}
}
