package com.example;

import javax.xml.ws.Endpoint;

public class Main {

	public static void main(String[] args) {
		
		
		String host = "localhost";
		
		if(args.length > 0 && args[0] != null) {
			host = args[0];
		}
		
		
		PoliticianService politicianService = new PoliticianService();		
		String endpointURL = "http://"+host+":5000/services/PoliticianService";
		Endpoint.publish(endpointURL, politicianService);
		System.out.println("SOAP Endpoint is running on : "+endpointURL);
	}
}
