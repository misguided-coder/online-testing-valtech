package com.example;

import java.util.HashMap;
import java.util.Map;

import javax.jws.WebService;

@WebService
public class PoliticianService {

	Map<String, String> assetsInMemoryDB = new HashMap<>();
	Map<String, String> fraudsInMemoryDB = new HashMap<>();

	public PoliticianService() {
		assetsInMemoryDB.put("Sonia", "500 CR");
		assetsInMemoryDB.put("Lalu", "700 CR");
		assetsInMemoryDB.put("Sibbal", "200 CR");
		assetsInMemoryDB.put("Rahul", "600 CR");
		assetsInMemoryDB.put("Raja", "900 CR");

		fraudsInMemoryDB.put("Sonia", "240");
		fraudsInMemoryDB.put("Lalu", "640");
		fraudsInMemoryDB.put("Sibbal", "350");
		fraudsInMemoryDB.put("Rahul", "900");
		fraudsInMemoryDB.put("Raja", "140");

	}

	public String showAssets(String name) {
		System.out.println("Inside PoliticianService.showAssets("+name+")!!!!");
		if (!assetsInMemoryDB.containsKey(name)) {
			return "No assets Found for " + name;
		} else {
			return assetsInMemoryDB.get(name);
		}
	}

	public String fraudCount(String name) {
		System.out.println("Inside PoliticianService.fraudCount("+name+")!!!!");
		if (!assetsInMemoryDB.containsKey(name)) {
			return "No frauds Found for " + name;
		} else {
			return fraudsInMemoryDB.get(name);
		}
	}
}
